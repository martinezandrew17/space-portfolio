export default function App() {
  return (
    <div className="h-screen w-screen flex items-center justify-center bg-void">
      <div className="text-center">
        <h1 className="font-display text-2xl mb-2">Space Portfolio — Scaffold Running ✅</h1>
        <p className="text-dim text-sm">
          Next step: build out Scene.tsx, the planets, and the content panel.
        </p>
      </div>
    </div>
  );
}
